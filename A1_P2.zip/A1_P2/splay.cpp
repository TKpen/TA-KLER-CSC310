#include "splay.h"

SplayTree::SplayTree() 
{
    root = nullptr; 
}

// aka Zig
SplayTree::Node* SplayTree::rotateRight(Node* x) {
    Node* y = x->left;
    x->left = y->right;
    y->right = x;
    return y;
}

// aka Zag
SplayTree::Node* SplayTree::rotateLeft(Node* x) {
    Node* y = x->right;
    x->right = y->left;
    y->left = x;
    return y;
}

// Splaying :)
SplayTree::Node* SplayTree::splay(Node* root, int key) {
    // If the key is already at root, return it (splayed position)
    if (root->key == key)
    {
        return root;
    }
    
    // Case: Key is in the left subtree
    if(root->key > key)
    {
        if (root->left == nullptr) return root; // Key not found
        // Zig-Zig (Left-Left case) - Rotate right twice if grandchild holds the key
        if(root->left->left != nullptr && root->left->left->key == key)
        {
            root = rotateRight(root);
        }
        // Zig-Zag (Left-Right case) - Recursively splay the left child
        if(root->left->right != nullptr && root->left->right->key == key)
        {
            root->left = splay(root->left, key);
        }
        // Final Zig (Left case) - Perform a single right rotation
        root->left = splay(root->left, key);
        root = rotateRight(root);
        
    }
    else //same but for right 
    {
        if(root->right == nullptr) return root; // Key not found
        if(root->right->right  && root->right->right->key == key)
        {
            root = rotateLeft(root);
        }

        if(root->right->left != nullptr && root->right->left->key == key)
        {
            root->right = splay(root->right, key);
        }

        root->right = splay(root->right, key);
        root = rotateLeft(root);
    }

    return root;
}


SplayTree::Node* SplayTree::insertNode(Node* root, int key) {//splay it when inserting ???n v   
    try {
        if (root == nullptr)
            return new Node(key);

        if (root->key > key)
            root->left = insertNode(root->left, key);
        else
            root->right = insertNode(root->right, key);

        return root;
    } catch (...) {
        cerr << "Error: Unable to insert key " << key << endl;
        return root;  // Return the unchanged root if insertion fails
    }
}


SplayTree::Node* SplayTree::deleteNode(Node* root, int key) {
    try {
        if (!root)
            throw runtime_error("Tree is empty, deletion not possible.");

        // Splay the given key
        root = splay(root, key);

        // If key is not found
        if (!root || root->key != key)
            throw runtime_error("Key not found in the tree.");

        Node* temp = root;

        // If left subtree is null, promote right subtree as root
        if (!root->left) {
            root = root->right;
        } else {
            // Replace with largest node from left subtree
            root = splay(root->left, key);
            root->right = temp->right;
        }

        delete temp;  // Proper memory management
    } catch (const exception& e) {
        cerr << "Error: " << e.what() << endl;
    } catch (...) {
        cerr << "Unknown error occurred during deletion." << endl;
    }

    return root;  // Always return root to maintain tree integrity
}

void SplayTree::insert(int key) {
    root = insertNode(root, key);
    root = splay(root, key);
}


void SplayTree::remove(int key) {
    root = deleteNode(root, key);
}


bool SplayTree::search(int key) {
    root = splay(root, key);
    return (root && root->key == key);
}


void SplayTree::printTree(Node* root, int space) {
    const int COUNT = 10; 

    if (root == nullptr) {
        return;
    }

    // Increase the distance between levels
    space += COUNT;

    // Print the right child first (to appear on top)
    printTree(root->right, space);

    // Print the current node after right child

    for (int i = COUNT; i < space; i++) {
        cout << " "; // Indentation for tree depth
    }
    cout << root->key << endl;

    // Print the left child
    printTree(root->left, space);
}

void SplayTree::display() {
    printTree(root, 0);
    cout << endl;
}
