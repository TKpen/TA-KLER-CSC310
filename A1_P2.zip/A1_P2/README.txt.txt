About: Splay tree Homework
Date: Feb 15, 2025
Comments: Includes three files -> splay.h, splay.cpp, mainsplay.cpp, Makefile, screenshot1
*** FIRST OPEN THE FOLDER WHERE THESE THREE FILES ARE LOCATED:
    In command prompt:
        cd folder-containing-the-files
        code .
*** 
To compile: make
To run: ./mainsplay 

Task 5:
Splaying keeps frequently accessed nodes near the root, making future operations on them faster. Less accessed nodes move deeper, but since each operation restructures the tree, it never stays unbalanced for long. While a single splay operation can take O(n) in the worst case, the amortized time complexity remains O(log n) because over multiple operations, the tree continuously self-adjusts.