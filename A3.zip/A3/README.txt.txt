About: AVL tree Homework
Date: March 4, 2025
Comments: Includes five files -> avl.h, main.cpp, avl.cpp, Makefile, screenshot1
*** FIRST OPEN THE FOLDER WHERE THESE THREE FILES ARE LOCATED:
    In command prompt:
        cd folder-containing-the-files
        code .
*** 
To compile: make
To run: ./avlOutput

 