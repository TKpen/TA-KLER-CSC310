#include "avl.h"

int main()
{
    AVLTree avl;

    avl.insert(99);
    avl.insert(14);
    avl.insert(23);
    avl.insert(8);
    //avl.insert(7);
    avl.insert(9);
    avl.insert(20);
    avl.insert(25);
    //avl.remove(25);
    //avl.remove(9);
    cout << "INSERTED avl: " << endl;
    avl.print();

    cout << "DELETION avl: " << endl;
    avl.remove(20);
    avl.print();

    return 0;
}