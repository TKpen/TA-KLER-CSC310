#include "avl.h"
AVLTree::AVLTree()
{
    root=nullptr;
}
AVLTree::~AVLTree()
{
    destroyTree(root);
}

void AVLTree::destroyTree(Node* node)
{
    if(node == nullptr)
        return;
    
    destroyTree(node->left);
    destroyTree(node->right);

    delete node;
}



Node* AVLTree::rotateLeft(Node* root)
{
    //backup the the right subtree
    Node* rightSubtree = root->right;
    //saving the left node of the rightsubtree
    Node* leftNodeSub = rightSubtree->left;

    //root becomes the child of rightsubtree
    rightSubtree->left = root;

    //root node recieves the leftNode of subrightreee
    root->right = leftNodeSub;

    //updating the height of the tree
    //updating the root height
    root->height = max(height(root->left), height(root->right)) + 1;
    //updating the height of the new root the rightsubtree
    rightSubtree->height = max(height(root->left), height(root->right)) + 1;

    //rightsubtree is the new root so ruturn it
    return rightSubtree;
}

Node* AVLTree::rotateRight(Node* root)
{
    //backup the left subtree
    Node* leftSubtree = root->left;
    //saving the leftsubtree right child to be transfroeed
    Node* rightNodeSub = leftSubtree->right;

    //Root becoems the child of leftsubtree
    leftSubtree->right = root;

    //root takes in the child of leftsubtree's right child
    root->left = rightNodeSub;

    //Changing the height
    //updating the height of root
    root->height = max(height(root->left), height(root->right)) + 1;
    //updaignt he height of the subtreeleft
    leftSubtree->height = max(height(leftSubtree->left), height(leftSubtree->right)) + 1;
    //sicne leftsubtree is now the root we return it
    return leftSubtree;
}

int AVLTree::height(Node* node)
{
    if(node == nullptr)
        return -1;//return a 1 if null instead of 0
    return node->height;
}

int AVLTree::getBalanceFactor(Node* node)
{
    if (node == nullptr)
        return 0;
    //get the height of the right and left subtree and subtract
    return height(node->right) - height(node->left);//
}
Node* AVLTree::insert(Node* node, int key)
{
    //insert
    try
    {
    
        if(node == nullptr)
            return new Node(key);
        
        if( node->key > key)
        {
            node->left = insert(node->left, key);
        } else if (node->key < key)
        {
            node->right = insert(node->right, key);
        }
        else
            return node;
    }   
    catch (const exception& e)
    {
        cerr << "Error in AVL insert" << e.what() << endl;
        return nullptr;
    }
    catch (...) // Catch all other unknown errors
    {
        cerr << "Unknown error occurred in AVL insert" << endl;
        return nullptr;
    }
    
    //update the height height
    node->height = max(height(node->left), height(node->right)) + 1;
    //balance factor
    int balance = getBalanceFactor(node);
    //avl rotations
    if(balance > 1 && key > node->right->key)
        return rotateLeft(node);
    if(balance > 1 && key < node->right->key)
    {
        node->right = rotateRight(node->right);
        return rotateLeft(node);
    }

    //greater 
    if(balance < -1 && key < node->left->key)
        return rotateRight(node);
    if(balance < -1 && key > node->left->key)
    {
        node->left = rotateLeft(node->left);
        return rotateRight(node);
    }

    return node;
}

Node* AVLTree::minValueNode(Node* node)
{
    Node* current = node;
    //loop dwon to find the min
    while(current->left != nullptr)  
        current = current->left;
    return current;
}

Node* AVLTree::remove(Node* node, int key)
{
    if (node == nullptr)
        return node;

    // NORMAL DELETION
    try
    {
        
        if (key < node->key)
            node->left = remove(node->left, key);
        else if (key > node->key)
            node->right = remove(node->right, key);
        else
        {
            // Case 1: No child
            if (node->left == nullptr && node->right == nullptr)
            {
                delete node;
                return nullptr;
            }
            // Case 2: One child
            else if (node->left == nullptr || node->right == nullptr)
            {
                Node* temp = (node->left) ? node->left : node->right;
                delete node;
                return temp;
            }
            // Case 3: Two children
            else
            {
                Node* temp = minValueNode(node->right); // Get min
                node->key = temp->key;  // Replace node
                node->right = remove(node->right, temp->key);  // Delete successor
            }
        }
    }
    catch (const exception& e) 
    {
        cerr << "Error in AVL remove" << e.what() << endl;
        return nullptr;
    }
    catch (...) // Catch all other unknown errors
    {
        cerr << "Unknown error occurred in AVL remove" << endl;
        return nullptr;
    }

    //THE SAME AS INSERT
    //update the height height
    node->height = max(height(node->left), height(node->right)) + 1;
    //balance factor
    int balance = getBalanceFactor(node);
    //avl rotations
    if(balance > 1 && key > node->right->key)
        return rotateLeft(node);
    if(balance > 1 && key < node->right->key)
    {
        node->right = rotateRight(node->right);
        return rotateLeft(node);
    }

    //greater 
    if(balance < -1 && key < node->left->key)
        return rotateRight(node);
    if(balance < -1 && key > node->left->key)
    {
        node->left = rotateLeft(node->left);
        return rotateRight(node);
    }

    return node;
}

void AVLTree::remove(int key)
{
    root = remove(root, key);
}

void AVLTree::printTree(Node* root, int space) {
    const int COUNT = 10; 

    if (root == nullptr) {
        return;
    }

    // Increase the distance between levels
    space += COUNT;

    // Print the right child first (to appear on top)
    printTree(root->right, space);

    // Print the current node after right child

    for (int i = COUNT; i < space; i++) {
        cout << " "; // Indentation for tree depth
    }
    cout << root->key << endl;

    // Print the left child
    printTree(root->left, space);
}

void AVLTree::print() {
    cout << endl;
    printTree(root, 0);
    cout << endl;
}

void AVLTree::insert(int key)
{
    root = insert(root, key);
}
