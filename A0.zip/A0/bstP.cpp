#include "bstP.h"
#include <stdexcept>

//this is the constructor declration
node::node(int value)
{
    data = value;
    leftChild = nullptr;
    rightChild = nullptr;
}

//Constructor for class BST sets the root to be NULL upon creation
BST::BST()
{
    root = nullptr;
}

//destructor deletes the tree...
BST::~BST()
{
    clearTree(root);
    // or call deleteNode
}

//clear tree function
void BST::clearTree(node* node)
{
    if (node == nullptr) {
        return; // Base case: if the current node is null, return
    }

    // Recursively delete the left and right subtrees
    clearTree(node->leftChild);
    clearTree(node->rightChild);

    // Delete the current node
    delete node;
}

//insert node in tree function
void BST:: insertNode(node*& root, int data)
{
    try {
        node* newNode = new node(data);
        node* current = root;

        //if root is empty
        if(root == nullptr)
        {
            root = newNode;
            return;
        }
        //if root is not empty
        //while loop to traverse through the tree to add in the new node
        while(1)
        {
            //no dublicates
            if (data == current->data) {
                throw runtime_error("Error: Duplicate value not allowed in BST.");
            }
            //check whether newNode is less than the current node
            if(newNode->data < current->data)
            {
                //breaks if the child is a null
                if (current->leftChild == nullptr)
                    break;
                current = current->leftChild;
            } else {
                if (current->rightChild == nullptr)
                    break;
                current = current->rightChild;
            }
        }
        //child becomes the new node
        if(newNode->data < current->data)
        {
            current->leftChild = newNode;
        } else {
            current->rightChild = newNode;
        }
    }
    catch (bad_alloc& e) {
        cerr << "Memory allocation failed" << e.what() << endl;
    }
    catch (exception& e) {
        cerr << "Exception: " << e.what() << endl;
    }
    
}

//searches node in the tree
node* BST:: searchNode(node*& root, int data)
{
    // Base case: root is null or data is found
    if (root == nullptr || root->data == data)
        return root;

    // Search in the left or right subtree based on BST property
    if (data < root->data)
        return searchNode(root->leftChild, data);
    else
        return searchNode(root->rightChild, data);
}

//deletes a node in the tree
void BST:: deleteNode(node*& root, int data)
{
    node* parent = root;
    node* current = root;

    while(1)
    {
        if (current == nullptr || current->data == data)
            break;

        if(data < current->data)
        {
            parent = current;
            current = current->leftChild;
        }
        else
        {
            parent = current;
            current = current->rightChild;
        }
    }
    
    //Exception
    if (current == nullptr) {
        throw std::runtime_error("Error: Node not found in the tree.");
    }

    //case 1, no children
    if (current->leftChild == nullptr && current->rightChild == nullptr)
    {
        if(parent->leftChild == current)
        {
            parent->leftChild = nullptr;
        } else {
            parent->rightChild = nullptr;
        }

        delete current;
    }

    //case 3, 2 children
    if (current->leftChild != nullptr && current->rightChild != nullptr)
    {
        node* min = current->rightChild;
         if (min->leftChild != nullptr && current->rightChild != nullptr)
         {
            while(1)
            {
                if (min->leftChild == nullptr)
                    break;

                if(0 < min->data)
                {
                    parent = min;
                    min = min->leftChild;
                }
            }
            //swaps the current to the min
            current->data = min->data;
            //goes and remove the node from the tree
            if (min->rightChild != nullptr)
            {
                parent->leftChild = min->rightChild;
            } else
            {
                parent->leftChild = nullptr;
            }
         } else {
            parent = current;
                        printf("==%d===", min->data);
            //swaps the current to the min
            current->data = min->data;
            //goes and remove the node from the tree
            if (min->rightChild != nullptr)
            {
                parent->rightChild = min->rightChild;
            } else
            {
                parent->rightChild = nullptr;
            }
         }
         delete min;

    }

    //case 2, one child
    if (current->leftChild == nullptr || current->rightChild == nullptr) {
        if(parent->leftChild == current)
        {
            parent->leftChild = current->rightChild;
        } else {
            parent->rightChild = current->rightChild;
        }
        delete current;
    }


}

//travels
void BST::preorder(node* root)
{
    node* current = root;
    //base case
    if( current == nullptr)
        return;

    cout << current->data << " ";
    // left
    preorder(current->leftChild);
    // right
    preorder(current->rightChild);
    // return
    return;

}
void BST::inorder(node* root)
{
    node* current = root;
    //base case
    if (current == nullptr)
        return;

    inorder(current->leftChild);

    cout << current->data << " ";

    inorder(current->rightChild);
    
    return;
}
void BST::postorder(node* root)
{
    // complete this
    node* current = root;
    //base case
    if (current == nullptr)
        return;

    postorder(current->leftChild);

    postorder(current->rightChild);
    cout << current->data << " ";
    
    return;
}


int BST::height(node* root)
{
    node* current = root;
    // complete this
    if (current == nullptr)
        return -1;

    int leftHeight = height(current->leftChild);
    int rightHeight = height(current->rightChild);

    return max(leftHeight, rightHeight) + 1;
}

void BST:: isBalanced(node* root)
{
    // find thte height of each side
    int leftSide = height(root->leftChild) + 1;
    
    int rightSide = height(root->rightChild) + 1;

    //compares the two sides
    int diff = abs(leftSide - rightSide);
    if (diff == 1 || diff == 0)
    {
        cout << "The tree is balanced" << endl;
    } else {
        cout << "The tree is unbalanced" << endl;
    }
}


//so it prints an actual looking tree...
void BST::printTree(node* root, int space) {
    const int COUNT = 10; 

    //if tree is empty return
    if (root == nullptr) {
        return;
    }

    // Increase the distance between levels
    space += COUNT;

    // Print the right child first (to appear on top)
    printTree(root->rightChild, space);

    // Print the current node after right child

    for (int i = COUNT; i < space; i++) {
        cout << " "; // Indentation for tree depth
    }
    cout << root->data << endl;

    // Print the left child
    printTree(root->leftChild, space);
}

