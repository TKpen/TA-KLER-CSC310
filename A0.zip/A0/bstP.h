#ifndef BSTP_H
#define BSTP_H

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

using namespace std;

//this is the structure of the node
struct node
{
    int data;
    struct node* leftChild;
    struct node* rightChild;

    node(int value); // this is a constructo declaration, used for creating new
};

//class for binary search tree
class BST {
    public:
        //creates the root node
        node* root;

        //The constructor for BST class
        BST();

        //the destructor, used for deltetion
        ~BST();

        //clears the entire node...
        void clearTree(node* node);

        //inserts node to the tree
        void insertNode(node*& root, int data); 
        //searches the node in the tree
        node* searchNode(node*& root, int data);
        //deletes a node in the tree(hard)
        void deleteNode(node*& root, int data);

        //Traversing the tree...
        void preorder(node* root);
        void inorder(node* root);
        void postorder(node* root);

        //find the height of the tree
        int height(node* root);
        //is the tree balanced...
        void isBalanced(node* root);

        //Prints the entire tree...
        void printTree(node* root, int space);

};

#endif 