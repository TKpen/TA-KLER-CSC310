About: BST Review Homework
Date: Jan 30, 2025
Comments: Includes three files -> bstP.h, bstP.cpp, mainP.cpp, Makefile, inst2, screenshot1, screenshot2

*** FIRST OPEN THE FOLDER WHERE THESE THREE FILES ARE LOCATED:
    In command prompt:
        cd folder-containing-the-files
        code .
*** 
To compile: make
To run: ./mainP inst2.txt 
