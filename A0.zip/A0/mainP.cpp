#include "bstP.h"

// Feel free to modify this
// this is already build
int main (int argc, char *argv[])
{
    if (argc != 2) {
        cerr << "Usage: ./a <filename>" << endl;
        return 1;
    }

    string filename = argv[1];

    BST tree;

    ifstream infile(filename);
    if (!infile) {
        cerr << "Error opening file.\n";
        return 1;
    }


    string line;
    while (getline(infile, line)) {
        istringstream iss(line);
        int command, data;

        iss >> command;
        //Important stuff
        switch (command) {
            case 0:// exit the progam
                cout << "Exiting...!\n";
                return 0;
            case 1:// inserts a node to the tree
                iss >> data;
                tree.insertNode(tree.root, data);
                cout << "Insert: " << data << endl;
                break;
            case 2:// search a node to the tree
                iss >> data;
                node* found;
                found = tree.searchNode(tree.root, data);
                if(found != nullptr)
                    cout<< data << " was found";
                else 
                    cout<< data << " was not found";
                cout<<endl;
                break;
            case 3:// deletes a node in the tree
                iss >> data;
                tree.deleteNode(tree.root, data);
                cout << "Node " << data << " is deleted!" << endl;
                break;
            case 4:// traversla inorder
                cout << "Inorder traversal: ";
                tree.inorder(tree.root);
                cout << endl;
                break;
            case 5:// travesal in preorder
                cout << "Preorder traversal: ";
                tree.preorder(tree.root);
                cout << endl;
                break;
            case 6:// traversal in postorder
                cout << "Postorder traversal: ";
                tree.postorder(tree.root);
                cout << endl;
                break;
            case 7:// prints an actual tree
                cout << "Binary Search Tree" << endl;
                tree.printTree(tree.root, 0);
                cout<<endl;
                break;
            case 8:
                int heightTree;
                heightTree = tree.height(tree.root);
                cout << "Binary Search Tree Height: " << heightTree << endl;
                tree.isBalanced(tree.root);
                break;
            default:// else
                cout << "Invalid command." << endl;
        }
    }


    return 0;
}