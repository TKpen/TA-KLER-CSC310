About: Splay tree Homework
Date: Feb 27, 2025
Comments: Includes five files -> dsw.h, main.cpp, dsw.cpp, Makefile, screenshot1
*** FIRST OPEN THE FOLDER WHERE THESE THREE FILES ARE LOCATED:
    In command prompt:
        cd folder-containing-the-files
        code .
*** 
To compile: make
To run: ./dswOutput

Task 5:
Phase 1 is less strict than standard DSW, allowing parents to retain a right child with a subtree of ≤2 nodes. This results in a more adaptable structure with a height close to 2 log₂(N), rather than exactly log₂(N). The trade-off is that the tree is not a perfect vine, therefore it stands significantly taller. A mirrored variation might use rigorous balancing without the subtree condition while still retaining a structured transformation. 