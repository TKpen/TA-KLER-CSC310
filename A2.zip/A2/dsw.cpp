#include "dsw.h"


//----------------Private------------
void BST::rotateRight(Node*& node) // passing the parent
{
    if(node == nullptr || node->left == nullptr)
        return;

    //get the nod eto rotate R
    Node* leftChild = node->left;
    // 1) node's right child is going to become parent's left child
    node->left = leftChild->right;
    // 2) Parent is going to be right child of node that is rotated
    leftChild->right = node;

    node = leftChild;

}

// when righ-heavy
void BST::rotateLeft(Node*& node)
{
    if(node == nullptr || node->right == nullptr)
        return;
    // get the node to rotate L
    Node* rightChild = node->right;

    // 1) node's left child is going to become parent's left child
    node->right = rightChild->left;
    // 2) parents is going to be left of nod ethat is rotated
    rightChild->left = node;

    node = rightChild;
}




// Phase 1 - left skewed linked list tree
void BST::createVine()
{
    if(root == nullptr)
        return;

    try
    {

        Node* grandparent = nullptr;
        Node* parent = root;
        Node* child = root->right;

        while(parent != nullptr)
        {
            if(child != nullptr && child->right != nullptr) // there is right child => Rotate left and stop if size is not > 2
            {
                rotateLeft(parent);
                if(grandparent == nullptr)
                    root = parent;
                else
                    grandparent->left = parent;
                    child = parent->right;

            } else { // no child - keep moving
                grandparent = parent;
                parent = parent->left;
                if (parent != nullptr)
                    child = parent->right;
            }
        }
    }
    catch (const std::runtime_error& e) {
        cerr << "Runtime ERROR: " << e.what() << endl;
    } 
    catch (const std::exception& e) {
        cerr << "EXCEPTION: " << e.what() << endl;
    } 
    catch (...) { 
        cerr << "ERROR: " << endl;
    }
}

// Phase 2 - rebuilding the tree
void BST::rebuildTree(int size)
{
    //How many right rotations
    int highestPowerof2 = 1 << (int)(log2(size + 1)); // Safe bitwise shift
    int m = (size + 1) - (1 << (highestPowerof2 / 2)); // Number of extra nodes

    performRotation(m);

    // Subsequent rotations
    for(size = (size - m) / 2; size > 0 ; size /= 2)
    {
        performRotation(size);
    }
}

// right rotate every second node based count
void BST::performRotation(int count)
{
    Node* grandparent = nullptr;
    Node* parent = root;
    Node* child = root->left;

    for(int i = 0; i < count; i++)
    {
        if(child == nullptr)
        {
            break;
        }

        rotateRight(parent);
        if(grandparent == nullptr)
            root = parent;
        else 
            grandparent->left = parent;
        
        grandparent = parent;
        parent = parent->left;
        if(parent != nullptr)
            child = parent->left;

    }
}

void BST::printTree(Node* root, int space) {
    const int COUNT = 10; 

    if (root == nullptr) {
        return;
    }

    // Increase the distance between levels
    space += COUNT;

    // Print the right child first (to appear on top)
    printTree(root->right, space);

    // Print the current node after right child

    for (int i = COUNT; i < space; i++) {
        cout << " "; // Indentation for tree depth
    }
    cout << root->data << endl;

    // Print the left child
    printTree(root->left, space);
}


//---------------- PUBLIC --------------------

BST::BST()
{
    root=nullptr;
}

BST::~BST()
{
    deleteTree(root);
}

void BST::deleteTree(Node*& node)
{
    if(node == nullptr)
        return;
    
    deleteTree(node->left);
    deleteTree(node->right);

    delete node;
}

void BST::insert(int val)
{
    try
    {
        
        Node* newNode = new Node(val);

        if(root == nullptr)
        {
            root = newNode;
            return;
        }

        Node* curr = root;
        Node* parent = nullptr;

        while(curr != nullptr)
        {
            parent = curr;
            if(val < curr->data)
                curr = curr->left;
            else
                curr = curr->right;
        }

        if(val < parent->data)
            parent->left = newNode;
        else 
            parent->right = newNode;
    }
    catch (const invalid_argument& e) {
        cerr << e.what() << endl;
    } 
    catch (const overflow_error& e) {
        cerr << e.what() << endl;
    } 
    catch (const exception& e) {
        cerr << "ERROR: " << e.what() << endl;
    }
}

void BST::dswBalance()
{
    if (root == nullptr)
        return;

    createVine();
    cout<< "After pahse 1"<< endl;
    display();

    int size = 0;
    Node* temp = root;
    while(temp != nullptr){
        size++;
        temp = temp->left;
    }
    rebuildTree(size);
}

void BST::display() {
    cout << endl;
    printTree(root, 0);
    cout << endl;
}